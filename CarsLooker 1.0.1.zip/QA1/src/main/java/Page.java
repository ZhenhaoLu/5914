public interface Page {
    void start();
    void next();
    void menu();
    void one();
    void two();
    void three();
    void four();
}
